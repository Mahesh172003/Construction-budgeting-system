package _CBS;

public class Check {

	interface Checker{
		boolean floorCountCheck();
		boolean roomCountCheck();
	}
}
