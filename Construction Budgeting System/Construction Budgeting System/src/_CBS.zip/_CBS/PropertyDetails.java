package _CBS;

public class PropertyDetails {
	public String soilType;
	public long area;
	public int floorCount,roomCount;
	public float landValue;
	public String getSoilType() {
		return soilType;
	}
	public void setSoilType(String soilType) {
		this.soilType = soilType;
	}
	public long getArea() {
		return area;
	}
	public void setArea(long area) {
		this.area = area;
	}
	public int getFloorCount() {
		return floorCount;
	}
	public void setFloorCount(int floorCount) {
		this.floorCount = floorCount;
	}
	public int getRoomCount() {
		return roomCount;
	}
	public void setRoomCount(int roomCount) {
		this.roomCount = roomCount;
	}
	public float getLandValue() {
		return landValue;
	}
	public void setLandValue(float landValue) {
		this.landValue = landValue;
	}
    
	
}
